
import React, { useState, useEffect, useCallback } from 'react';
import { Chat, Part } from '@google/genai';
import { Message, ChatSession } from './types';
import { createChat } from './services/geminiService';
import Header from './components/Header';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';
import Login from './components/Login';
import SavedChatsModal from './components/SavedChatsModal';
import Toast from './components/Toast';

type Theme = 'light' | 'dark';

declare global {
  interface Window {
    jspdf: any;
    html2canvas: any;
  }
}

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  
  // Text chat state
  const [chat, setChat] = useState<Chat | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Shared state
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [theme, setTheme] = useState<Theme>('light');
  const [isSavedChatsOpen, setIsSavedChatsOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  // --- Core Session Management ---

  const createNewSession = useCallback((): ChatSession => ({
    id: `chat_${Date.now()}`,
    name: 'New Conversation',
    createdAt: Date.now(),
    messages: [],
  }), []);

  // --- Lifecycle & Data Persistence Effects ---
  
  useEffect(() => {
    // Initial load from localStorage
    const storedUser = localStorage.getItem('darul_uloom_gpt_user');
    if (storedUser) setCurrentUser(storedUser);
    
    const storedTheme = localStorage.getItem('darul_uloom_gpt_theme') as Theme;
    if (storedTheme) {
      setTheme(storedTheme);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
    }
  }, []);
  
  useEffect(() => {
    // Theme side-effect
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('darul_uloom_gpt_theme', theme);
  }, [theme]);

  useEffect(() => {
    // User login side-effect
    if (currentUser) {
      try {
        setChat(createChat());

        const storedSessions = localStorage.getItem(`chat_sessions_${currentUser}`);
        const storedActiveId = localStorage.getItem(`active_chat_id_${currentUser}`);
        
        if (storedSessions) {
            const parsedSessions: ChatSession[] = JSON.parse(storedSessions);
            setChatSessions(parsedSessions);
            if (storedActiveId && parsedSessions.some(s => s.id === storedActiveId)) {
                setActiveChatId(storedActiveId);
            } else if (parsedSessions.length > 0) {
                setActiveChatId(parsedSessions[0].id);
            } else {
                 const newSession = createNewSession();
                 setChatSessions([newSession]);
                 setActiveChatId(newSession.id);
            }
        } else {
          const newSession = createNewSession();
          setChatSessions([newSession]);
          setActiveChatId(newSession.id);
        }
      } catch (e) {
        console.error(e);
        setError("An error occurred during initialization.");
      }
    }
  }, [currentUser, createNewSession]);

  useEffect(() => {
    // Persist chat sessions to localStorage, stripping image data for privacy.
    if (currentUser && chatSessions.length > 0) {
      const sessionsToSave = chatSessions.map(session => ({
        ...session,
        messages: session.messages.map(({ image, ...message }) => message) // remove image property
      }));
      localStorage.setItem(`chat_sessions_${currentUser}`, JSON.stringify(sessionsToSave));
    }
    if (currentUser && activeChatId) {
        localStorage.setItem(`active_chat_id_${currentUser}`, activeChatId);
    }
  }, [chatSessions, activeChatId, currentUser]);
  
  useEffect(() => {
    if (toastMessage) {
        const timer = setTimeout(() => {
            setToastMessage(null);
        }, 3000);
        return () => clearTimeout(timer);
    }
  }, [toastMessage]);
  
  // --- Text Chat Logic ---

  const handleSendMessage = async (text: string, media?: { mimeType: string, data: string }) => {
    if (!chat || isLoading || (!text.trim() && !media) || !activeChatId) return;

    // Image validation check
    const imageKeywords = [
        'what is this', 'where is this', 'analyze this', 'identify this', 
        'explain this', 'describe this', 'this image', 'this picture', 'this video',
        'about this image'
    ];
    const lowercasedText = text.trim().toLowerCase();
    const impliesImageQuery = imageKeywords.some(keyword => lowercasedText.includes(keyword));

    if (impliesImageQuery && !media) {
        const userMessage: Message = { id: Date.now(), text, sender: 'user' };
        const validationMessage: Message = { 
            id: Date.now() + 1, 
            text: "Please upload an image first.", 
            sender: 'model',
            isLoading: false,
            isError: true,
        };
        
        updateActiveChat(session => ({
            ...session,
            messages: [...session.messages, userMessage, validationMessage]
        }));
        return; // Stop execution, don't call Gemini
    }

    setIsLoading(true);
    
    const promptText = (media && !text.trim()) 
      ? "Analyze this image or video and provide relevant Islamic explanations, guidance, or identification." 
      : text;

    const userMessage: Message = { 
        id: Date.now(), 
        text: promptText, 
        sender: 'user',
        image: media ? `data:${media.mimeType};base64,${media.data}` : undefined,
    };
    const loadingMessage: Message = { id: Date.now() + 1, text: '', sender: 'model', isLoading: true };

    updateActiveChat(session => {
        const isFirstUserMessage = session.messages.filter(m => m.sender === 'user').length === 0;
        const newName = (promptText + (media ? " (media)" : "")).substring(0, 40)
        return {
            ...session,
            name: isFirstUserMessage ? newName + (newName.length >= 40 ? '...' : '') : session.name,
            messages: [...session.messages, userMessage, loadingMessage]
        };
    });

    try {
      const messageParts: Part[] = [];
      if (media) {
        messageParts.push({
          inlineData: {
            mimeType: media.mimeType,
            data: media.data,
          }
        });
      }
      messageParts.push({ text: promptText });

      const stream = await chat.sendMessageStream({ message: messageParts });
      let currentResponse = '';
      for await (const chunk of stream) {
        currentResponse += chunk.text;
        updateActiveChat(session => ({
            ...session,
            messages: session.messages.map(msg =>
                msg.isLoading ? { ...msg, text: currentResponse } : msg
            ),
        }));
      }
      updateActiveChat(session => ({
          ...session,
          messages: session.messages.map(msg =>
              msg.isLoading ? { ...msg, isLoading: false } : msg
          ),
      }));
    } catch (e) {
      console.error("Error sending message:", e);
      const errorMessage = "Sorry, I encountered an error. Please try again.";
      updateActiveChat(session => ({
          ...session,
          messages: session.messages.map(msg =>
              msg.isLoading ? { ...msg, text: errorMessage, isLoading: false, isError: true } : msg
          ),
      }));
    } finally {
      setIsLoading(false);
    }
  };

  // --- Utility & UI Handlers ---

  const handleExportPDF = async () => {
    const chatContainer = document.getElementById('chat-container');
    if (!chatContainer || (chatSessions.find(s => s.id === activeChatId)?.messages.length ?? 0) === 0) {
      setToastMessage("Cannot export an empty chat.");
      return;
    }
    
    setToastMessage("Generating PDF...");

    try {
      const { jsPDF } = window.jspdf;

      // Clone the node to capture full content without altering the live view
      const printContainer = chatContainer.cloneNode(true) as HTMLElement;
      printContainer.id = "print-container";
      
      // Style the clone to be fully visible but off-screen
      printContainer.style.position = 'absolute';
      printContainer.style.left = '-9999px';
      printContainer.style.top = '0px';
      printContainer.style.overflow = 'visible';
      printContainer.style.height = 'auto'; 
      printContainer.style.width = chatContainer.offsetWidth + 'px';

      document.body.appendChild(printContainer);

      const header = document.createElement('div');
      header.className = `p-4 text-center ${theme === 'light' ? 'bg-white text-gray-800' : 'bg-gray-800 text-gray-200'}`;
      header.innerHTML = `<h1 class="text-xl font-bold">Darul Uloom GPT Chat</h1><p class="text-sm ${theme === 'light' ? 'text-gray-500' : 'text-gray-400'}">${new Date().toLocaleString()}</p>`;
      printContainer.prepend(header);
      
      const canvas = await window.html2canvas(printContainer, {
          scale: 2,
          useCORS: true,
          backgroundColor: theme === 'light' ? '#ffffff' : '#1f2937',
      });

      document.body.removeChild(printContainer); // Clean up

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      const imgData = canvas.toDataURL('image/png');
      const imgProps = pdf.getImageProperties(imgData);
      const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
      heightLeft -= pdfHeight;

      while (heightLeft > 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
          heightLeft -= pdfHeight;
      }

      const dateStr = new Date().toISOString().split('T')[0];
      pdf.save(`DarulUloomGPT_Chat_${dateStr}.pdf`);
      setToastMessage("✅ Chat saved successfully as PDF.");
    } catch (error) {
      console.error("Error exporting PDF:", error);
      setToastMessage("Error exporting PDF.");
      setError("Failed to export chat as PDF.");
    }
  };


  const updateActiveChat = (updater: (session: ChatSession) => ChatSession) => {
    setChatSessions(prevSessions =>
      prevSessions.map(session =>
        session.id === activeChatId ? updater(session) : session
      )
    );
  };
  
  const handleStartNewChat = () => {
    const newSession = createNewSession();
    setChatSessions(prev => [newSession, ...prev]);
    setActiveChatId(newSession.id);
  };
  
  const handleClearCurrentChat = () => {
    if (!activeChatId) return;
    updateActiveChat(() => ({ ...createNewSession(), id: activeChatId }));
  };

  const handleSwitchChat = (id: string) => {
    setActiveChatId(id);
    setIsSavedChatsOpen(false);
  }

  const handleDeleteChat = (id: string) => {
    let newSessions = chatSessions.filter(s => s.id !== id);
    if (newSessions.length === 0) {
        newSessions = [createNewSession()];
    }
    setChatSessions(newSessions);
    
    if (activeChatId === id) {
        setActiveChatId(newSessions[0].id);
    }
  };

  const handleRenameChat = (id: string, newName: string) => {
    setChatSessions(prev => prev.map(s => s.id === id ? {...s, name: newName} : s));
  };

  const handleLogin = (username: string) => {
    localStorage.setItem('darul_uloom_gpt_user', username);
    setCurrentUser(username);
  };

  const handleLogout = () => {
    localStorage.removeItem('darul_uloom_gpt_user');
    setCurrentUser(null);
    setChat(null);
    setChatSessions([]);
    setActiveChatId(null);
    setError(null);
  };
  
  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  if (!currentUser) {
    return <Login onLogin={handleLogin} />;
  }
  
  const activeMessages = chatSessions.find(s => s.id === activeChatId)?.messages || [];

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <Header 
        currentUser={currentUser} 
        onLogout={handleLogout}
        onNewChat={handleStartNewChat}
        onClearChat={handleClearCurrentChat}
        onViewSaved={() => setIsSavedChatsOpen(true)}
        onExportPDF={handleExportPDF}
        theme={theme}
        onToggleTheme={toggleTheme}
      />
      {error && (
        <div className="text-center p-2 bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300">
          <p>{error}</p>
        </div>
      )}
      <ChatHistory messages={activeMessages} />
      <ChatInput 
        onSendMessage={handleSendMessage} 
        isLoading={isLoading}
      />
      <SavedChatsModal
        isOpen={isSavedChatsOpen}
        onClose={() => setIsSavedChatsOpen(false)}
        chatSessions={chatSessions}
        activeChatId={activeChatId}
        onSwitchChat={handleSwitchChat}
        onDeleteChat={handleDeleteChat}
        onRenameChat={handleRenameChat}
       />
       <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
};

export default App;

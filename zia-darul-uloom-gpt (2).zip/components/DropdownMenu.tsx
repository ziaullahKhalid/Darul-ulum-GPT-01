import React from 'react';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { ArchiveIcon } from './icons/ArchiveIcon';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';
import { LogoutIcon } from './icons/LogoutIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface DropdownMenuProps {
    onNewChat: () => void;
    onClearChat: () => void;
    onViewSaved: () => void;
    onExportPDF: () => void;
    theme: 'light' | 'dark';
    onToggleTheme: () => void;
    onLogout: () => void;
    onClose: () => void;
}

const DropdownMenu: React.FC<DropdownMenuProps> = ({ onNewChat, onClearChat, onViewSaved, onExportPDF, theme, onToggleTheme, onLogout, onClose }) => {
    
    const handleAction = (action: () => void) => {
        action();
        onClose();
    };

    const menuItems = [
        { label: 'Start New Chat', icon: <PlusIcon />, action: () => handleAction(onNewChat) },
        { label: 'View Saved Chats', icon: <ArchiveIcon />, action: () => handleAction(onViewSaved) },
        { label: 'Save Chat as PDF', icon: <DownloadIcon />, action: () => handleAction(onExportPDF) },
        { label: 'Clear Current Chat', icon: <TrashIcon />, action: () => handleAction(onClearChat) },
        { label: `Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`, icon: theme === 'light' ? <MoonIcon /> : <SunIcon />, action: () => handleAction(onToggleTheme) },
        { label: 'Logout', icon: <LogoutIcon />, action: () => handleAction(onLogout) },
    ];
    
    return (
        <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-30">
            <div className="py-1">
                {menuItems.map((item) => (
                    <button
                        key={item.label}
                        onClick={item.action}
                        className="w-full text-left flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                        <span className="mr-3">{item.icon}</span>
                        {item.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default DropdownMenu;
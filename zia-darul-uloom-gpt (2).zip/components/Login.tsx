import React, { useState } from 'react';

interface LoginProps {
  onLogin: (username: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onLogin(username.trim());
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-50 dark:bg-gray-900 p-4 transition-colors duration-300">
      <div className="w-full max-w-sm p-8 space-y-6 bg-white dark:bg-gray-800 rounded-lg shadow-md text-center">
        <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Welcome to</h1>
        <h2 className="text-3xl font-bold text-black dark:text-white">Darul Uloom GPT</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Please enter a username to save and access your chat history.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="sr-only">Username</label>
            <input
              id="username"
              name="username"
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2 text-center text-gray-900 bg-white dark:bg-gray-700 dark:text-gray-200 border border-black dark:border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-black/50 dark:focus:ring-white/50"
              placeholder="Enter your username"
            />
          </div>
          <button
            type="submit"
            className="w-full px-4 py-3 font-semibold text-white bg-black rounded-full hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black dark:bg-gray-200 dark:text-black dark:hover:bg-gray-300 dark:focus:ring-gray-400 transition-colors duration-200"
          >
            Start Chatting
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;

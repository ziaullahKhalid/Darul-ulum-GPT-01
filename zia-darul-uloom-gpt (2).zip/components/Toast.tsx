import React from 'react';
import { XMarkIcon } from './icons/XMarkIcon';

interface ToastProps {
    message: string | null;
    onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, onClose }) => {
    if (!message) return null;

    return (
        <div className="fixed top-5 right-5 z-50">
            <div className="flex items-center justify-between max-w-xs p-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg ring-1 ring-black ring-opacity-5">
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{message}</p>
                <button
                    onClick={onClose}
                    className="ml-4 p-1 rounded-full text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                    aria-label="Close"
                >
                    <XMarkIcon />
                </button>
            </div>
        </div>
    );
};

export default Toast;

import React, { useState, useRef, useEffect } from 'react';
import { ChatSession } from '../types';
import { PencilIcon } from './icons/PencilIcon';
import { TrashIcon } from './icons/TrashIcon';
import { XMarkIcon } from './icons/XMarkIcon';

interface SavedChatsModalProps {
    isOpen: boolean;
    onClose: () => void;
    chatSessions: ChatSession[];
    activeChatId: string | null;
    onSwitchChat: (id: string) => void;
    onDeleteChat: (id: string) => void;
    onRenameChat: (id: string, newName: string) => void;
}

const SavedChatsModal: React.FC<SavedChatsModalProps> = ({
    isOpen,
    onClose,
    chatSessions,
    activeChatId,
    onSwitchChat,
    onDeleteChat,
    onRenameChat,
}) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const [renameText, setRenameText] = useState('');
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (editingId && inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, [editingId]);
    
    if (!isOpen) return null;

    const handleRenameClick = (session: ChatSession) => {
        setEditingId(session.id);
        setRenameText(session.name);
    };

    const handleRenameSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (editingId && renameText.trim()) {
            onRenameChat(editingId, renameText.trim());
        }
        setEditingId(null);
    };
    
    const formatDate = (timestamp: number) => {
        return new Date(timestamp).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    }

    return (
        <div className="fixed inset-0 bg-black/60 z-40 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">Saved Chats</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600">
                        <XMarkIcon />
                    </button>
                </div>
                <div className="overflow-y-auto p-4">
                    <ul className="space-y-2">
                        {chatSessions.map(session => (
                            <li key={session.id} className={`p-3 rounded-lg flex items-center justify-between group transition-colors ${activeChatId === session.id ? 'bg-black text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>
                                <div className="flex-grow cursor-pointer" onClick={() => onSwitchChat(session.id)}>
                                    {editingId === session.id ? (
                                        <form onSubmit={handleRenameSubmit}>
                                            <input
                                                ref={inputRef}
                                                type="text"
                                                value={renameText}
                                                onChange={e => setRenameText(e.target.value)}
                                                onBlur={handleRenameSubmit}
                                                className="w-full bg-transparent border-b border-gray-400 focus:outline-none"
                                            />
                                        </form>
                                    ) : (
                                        <>
                                            <p className={`font-semibold truncate ${activeChatId === session.id ? 'text-white' : 'text-gray-900 dark:text-gray-200'}`}>{session.name}</p>
                                            <p className={`text-xs ${activeChatId === session.id ? 'text-gray-300' : 'text-gray-500 dark:text-gray-400'}`}>{formatDate(session.createdAt)}</p>
                                        </>
                                    )}
                                </div>
                                <div className={`flex items-center space-x-2 pl-2 ${activeChatId !== session.id ? 'opacity-0 group-hover:opacity-100' : ''}`}>
                                    <button onClick={() => handleRenameClick(session)} className={`p-2 rounded-full ${activeChatId === session.id ? 'hover:bg-gray-600' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                                        <PencilIcon />
                                    </button>
                                    <button onClick={() => onDeleteChat(session.id)} className={`p-2 rounded-full ${activeChatId === session.id ? 'hover:bg-gray-600' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                                        <TrashIcon />
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default SavedChatsModal;


import React, { useState, useRef } from 'react';
import { SendIcon } from './icons/SendIcon';
import { PaperClipIcon } from './icons/PaperClipIcon';
import { XMarkIcon } from './icons/XMarkIcon';

interface ChatInputProps {
  onSendMessage: (text: string, media?: { mimeType: string, data: string }) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ 
    onSendMessage, 
    isLoading,
}) => {
  const [text, setText] = useState('');
  const [mediaFile, setMediaFile] = useState<{ file: File; previewUrl: string; type: 'image' | 'video' } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit for Gemini inline data
        alert('File is too large. Please select a file under 4MB.');
        return;
      }
      const previewUrl = URL.createObjectURL(file);
      const fileType = file.type.startsWith('video/') ? 'video' : 'image';
      setMediaFile({ file, previewUrl, type: fileType });
    }
  };

  const removeMedia = () => {
    if (mediaFile) {
      URL.revokeObjectURL(mediaFile.previewUrl);
    }
    setMediaFile(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || (!text.trim() && !mediaFile)) return;

    let mediaPayload;
    if (mediaFile) {
      try {
        const base64Data = await fileToBase64(mediaFile.file);
        mediaPayload = {
          mimeType: mediaFile.file.type,
          data: base64Data,
        };
      } catch (error) {
        console.error("Error converting file to base64:", error);
        alert("Could not process the file. Please try another one.");
        return;
      }
    }
    
    onSendMessage(text, mediaPayload);
    setText('');
    removeMedia();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e as unknown as React.FormEvent);
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-2 sm:p-4 sticky bottom-0 transition-colors duration-300">
      {mediaFile && (
        <div className="relative w-24 h-24 mx-auto mb-2 group">
            {mediaFile.type === 'video' ? (
                <video src={mediaFile.previewUrl} className="w-full h-full object-cover rounded-md" controls />
            ) : (
                <img src={mediaFile.previewUrl} alt="Image preview" className="w-full h-full object-cover rounded-md" />
            )}
            <button 
                onClick={removeMedia} 
                className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Remove media"
            >
                <XMarkIcon />
            </button>
        </div>
      )}
      <div className="flex items-center max-w-3xl mx-auto">
        <form onSubmit={handleSubmit} className="flex items-center w-full">
            <input 
                type="file" 
                accept="image/*,video/*"
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                disabled={isLoading}
            />
            <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="mr-2 sm:mr-4 flex-shrink-0 text-gray-600 dark:text-gray-300 hover:text-black dark:hover:text-white transition-colors duration-200 disabled:opacity-50"
                aria-label="Attach media"
            >
                <PaperClipIcon />
            </button>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your question here..."
              disabled={isLoading}
              rows={1}
              className="flex-grow resize-none p-3 text-base bg-white dark:bg-gray-700 dark:text-gray-200 border border-black dark:border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-black/50 dark:focus:ring-white/50 transition duration-200 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isLoading || (!text.trim() && !mediaFile)}
              className="ml-2 sm:ml-4 flex-shrink-0 bg-black text-white rounded-full p-3 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black dark:bg-gray-200 dark:text-black dark:hover:bg-gray-300 dark:focus:ring-gray-400 transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
              aria-label="Send message"
            >
              <SendIcon />
            </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInput;

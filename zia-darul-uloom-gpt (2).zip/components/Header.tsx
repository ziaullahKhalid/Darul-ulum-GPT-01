import React, { useState, useRef, useEffect } from 'react';
import { LogoutIcon } from './icons/LogoutIcon';
import { MenuIcon } from './icons/MenuIcon';
import DropdownMenu from './DropdownMenu';

interface HeaderProps {
    currentUser: string | null;
    onLogout: () => void;
    onNewChat: () => void;
    onClearChat: () => void;
    onViewSaved: () => void;
    onExportPDF: () => void;
    theme: 'light' | 'dark';
    onToggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentUser, onLogout, onNewChat, onClearChat, onViewSaved, onExportPDF, theme, onToggleTheme }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="bg-black text-white p-4 flex items-center justify-between shadow-md z-20">
      <h1 className="text-xl md:text-2xl font-bold">Darul Uloom GPT</h1>
      {currentUser && (
        <div className="flex items-center space-x-2 sm:space-x-4">
            <span className="text-sm md:text-base hidden sm:block">Welcome, {currentUser}</span>
            <div className="relative" ref={menuRef}>
                <button
                    onClick={() => setIsMenuOpen(prev => !prev)}
                    className="p-2 rounded-full hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-white"
                    aria-label="Open menu"
                >
                    <MenuIcon />
                </button>
                {isMenuOpen && (
                    <DropdownMenu
                        onNewChat={onNewChat}
                        onClearChat={onClearChat}
                        onViewSaved={onViewSaved}
                        onExportPDF={onExportPDF}
                        theme={theme}
                        onToggleTheme={onToggleTheme}
                        onLogout={onLogout}
                        onClose={() => setIsMenuOpen(false)}
                    />
                )}
            </div>
        </div>
      )}
    </header>
  );
};

export default Header;
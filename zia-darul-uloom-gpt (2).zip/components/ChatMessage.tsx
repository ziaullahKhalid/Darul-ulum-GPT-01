
import React from 'react';
import { Message } from '../types';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import TypingIndicator from './TypingIndicator';

interface ChatMessageProps {
  message: Message;
}

declare global {
    interface Window {
        marked: {
            parse: (markdown: string) => string;
        };
    }
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUserModel = message.sender === 'model';
  // Comprehensive regex for Arabic script used in Urdu, Arabic, Persian etc.
  const containsRtl = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(message.text);

  const messageClasses = `max-w-xl lg:max-w-2xl px-4 py-3 rounded-2xl shadow-sm break-words relative`;
  const userClasses = `bg-black text-white self-end`;
  const modelClasses = `bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 self-start`;
  const errorClasses = `bg-red-100 text-red-700 border border-red-200`;
  
  const createMarkup = (text: string) => {
    if (message.sender === 'user') {
      const sanitizedText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return { __html: sanitizedText.replace(/\n/g, '<br />') };
    }
    return { __html: window.marked.parse(text) };
  };
  
  const renderContent = () => {
    const proseContainerClasses = `prose prose-sm dark:prose-invert max-w-none ${containsRtl ? '[direction:rtl] text-right [unicode-bidi:plaintext]' : ''}`;
    const isVideo = message.image?.startsWith('data:video');

    if (message.isLoading) {
      // If there's no text yet, just show the indicator centered.
      if (!message.text) {
        return <div className="flex justify-center p-2"><TypingIndicator /></div>;
      }
      // If text is streaming, show text and indicator below.
      return (
        <>
          <div className={proseContainerClasses} dangerouslySetInnerHTML={createMarkup(message.text)} />
          <TypingIndicator />
        </>
      );
    }

    // Final message content
    return (
      <>
        {message.image && (
            isVideo ? (
                <video src={message.image} controls className="mb-2 rounded-lg max-w-full max-h-64 object-contain" />
            ) : (
                <img src={message.image} alt="User upload" className="mb-2 rounded-lg max-w-full max-h-64 object-contain" />
            )
        )}
        <div className={proseContainerClasses} dangerouslySetInnerHTML={createMarkup(message.text)} />
        {isUserModel && !message.isError && (
            <div className="flex items-center justify-end mt-2 text-xs text-green-600 dark:text-green-400">
                <CheckCircleIcon />
                <span className="ml-1 font-semibold">Verified by Scholar</span>
            </div>
        )}
      </>
    );
  };


  return (
    <div className={`flex ${isUserModel ? 'justify-start' : 'justify-end'}`}>
      <div
        className={`${messageClasses} ${
          isUserModel ? modelClasses : userClasses
        } ${message.isError ? errorClasses : ''}`}
      >
        {renderContent()}
      </div>
    </div>
  );
};

export default ChatMessage;

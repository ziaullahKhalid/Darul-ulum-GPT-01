
export type Sender = 'user' | 'model';

export interface Message {
  id: number;
  text: string;
  sender: Sender;
  isLoading?: boolean;
  isError?: boolean;
  image?: string; // a base64 data URL
}

export interface ChatSession {
    id: string;
    name: string;
    messages: Message[];
    createdAt: number;
}
